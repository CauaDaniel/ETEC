#Desenvolva um programa que converta de Graus Fahrenheit para Graus Celsius.
Fah = int (input('Digite quantos Graus Fahrenheit você deseja converter: '))
con = (Fah - 32) / 1.8
print('Os Graus Fahrenheit convertidos para Graus Celsius, são iguais à: {}'.format(con))