#Escreva um programa que leia em valor em metros e o exiba convertido em centímetros e milímetros.
n1 = int (input('Qual o valor em metors que deseja converter? '))
c = (n1 *100)
mm = (n1 * 1000)
print('{} metros convertido para centímetros é igual à: {} \n E milímetros: {}'.format(n1,c,mm))