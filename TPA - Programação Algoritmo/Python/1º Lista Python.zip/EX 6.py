#Crie um programa que leia quanto dinheiro ele tem na carteira e mostre quantos dólares ela pode comprar.
di = float (input('Digite quanto de dinheiro você tem em sua carteira: '))
co = float (input('Digite a cotação do dólar atual: '))
d =  int (di / co)
print('Você tem R${} na sua carteira \n Você pode comprar ${}.'.format(di,d))
