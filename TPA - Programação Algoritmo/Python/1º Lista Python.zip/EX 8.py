#Faça um programa que leia o salário de um funcionário e mostre seu novo salário com 15% de aumento.

sf = float (input('Digite o salário do funcionário: R$'))
ns = (sf + 0.15 * 100)
print('O salário do funcionário com 15% de aumento: R${}'.format(ns))