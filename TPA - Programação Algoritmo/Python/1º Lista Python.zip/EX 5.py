# Faça um programa que leia três número inteiro qualquer e mostre na tela o produto deles.
n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro número: '))
n3 = int(input('Digite mais um número: '))
p = (n1 + n2 + n3)
print('O produto de "{} + {} + {}" é igual a: {}'.format(n1,n2,n3,p))