#  Faça um programa que leia um número inteiro e mostre na tela o seu sucessor e seu antecessor
import  math
n1 = int(input('Insira um número: '))
s = (n1 + 1)
a = (n1 - 1 )
print('O número sucessor de "{}" é: {} \n O antecessor é: {}' .format(n1 ,s, a))