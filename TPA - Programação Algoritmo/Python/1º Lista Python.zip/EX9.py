#Faça um programa que leia o preço de um produto e mostre seu novo preço com 7% de desconto.
pp = float (input('Digite o preço do produto: R$'))
np = (pp - 0.07 * 100)
print('O novo preço do produto com 7% de desconto: R${}'.format(np))