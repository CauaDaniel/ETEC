#Faça um programa que leia a largura e a altura de uma parede em metros, calcule a sua área e a quantidade de tinta
# necessária para pintá-la, sabendo que cada litro de tinta pinta uma área de 2.3m².

l = int (input('Qual a largura dessa parede? '))
a = int (input('E qual a altura dela? '))
area = l * a
tinta = (area / 2.3)
print('A área de sua parede é de {}m² \n A quantia de tinta necessária para pintá-la é de {:.4} litros.'.format(area,tinta) )