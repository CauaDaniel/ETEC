#Crie um programa que leia um número e mostre o seu dobro, triplo e raiz quadrada.
import math
n1 = int (input('Digite o número: '))
d = (n1 * 2)
t = (n1 * 3)
raiz = math.sqrt(n1)
print('O dobro de {} é: {} \n O triplo é: {} \n A raiz quadrada é: {}'.format(n1,d,t,raiz))