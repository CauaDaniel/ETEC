#Desenvolva um programa que leia as quatro notas de um aluno e calcule e mostre a sua média.

n1 = int (input('Qual a primeira nota deste aluno(a)? '))
n2 = int (input('Qual a segunda nota deste aluno(a)? '))
n3 = int (input('Qual a terceira nota deste aluno(a)? '))
n4 = int (input('Qual a quarta nota deste aluno(a)? '))
m = (n1 + n2 + n3 + n4) / 4
print('A média das quatro notas deste aluno(a), é: {}'.format(m))

