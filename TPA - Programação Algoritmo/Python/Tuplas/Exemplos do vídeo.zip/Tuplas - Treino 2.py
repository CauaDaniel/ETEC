a = (2,5,4)
b = (5,8,1,2)
c = a + b
print(c) #Juntar as tuplas, não a somam
print ('existem',len(c),'números')
print('5 aparece:',c.count(5),'vezes')
print('5 está na posição:',c.index(5, 1))

