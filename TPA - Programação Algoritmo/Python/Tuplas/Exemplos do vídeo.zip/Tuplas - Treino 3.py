pessoa = ('Cauã',39,'M',98.88)
del (pessoa) #Vai dar erro, pois esse comando deletou a tupla, antes do print
#del não pode deletar elementos dentro de uma tupla, apenas ela INTEIRA.
print(pessoa)