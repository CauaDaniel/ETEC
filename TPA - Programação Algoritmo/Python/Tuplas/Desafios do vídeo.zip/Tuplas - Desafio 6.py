palavras = ('acordar','escovar','cafe da manha','estudar','almoco','janta','dormir','descanso')
for pv in palavras:
    print(f'\nNa palavra {pv}, temos estas vogais: ')
    for vogal in pv:
        if vogal in 'aeiou':
            print(vogal, end=' ')
