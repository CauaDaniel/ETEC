from random import *
n = randint(1,10),randint(1,10),randint(1,10),randint(1,10),randint(1,10)
print('Sorteei os seguintes valores:',n)
print('O maior número sorteado foi:',max(n))
print('O menor número sorteado foi:',min(n))







