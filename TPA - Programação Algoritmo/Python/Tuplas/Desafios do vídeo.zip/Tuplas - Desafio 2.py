times = ('Palmeiras','Internacional','Corinthians','Flamengo','Fluminense','Athletico-PR','Atlético-MG','América-MG','Botafogo','Fortaleza','São Paulo','Bragantino','Goiás','Coritiba','Ceará','Atlético-GO','Avaí','Juventude')

print('=-=-=->  Os 5 primeiros colocados são:  <-=-=-=')
print(times[0:5])
print('=-=-=->  Os ultimos 4 colocados são:  <-=-=-=')
print(times[17:20])
print('=-=-=->  Lista dos times em ordem alfabética:  <-=-=-=')
print (sorted(times))
print('O time da Chapecoense não está em nenhuma posição na tabela!')
