n = ('zero','um','dois','três','quatro','cinco','seis','sete','oito','nove','dez','onze','doze','treze','catorze','quinze','dezesseis','dezessete','dezoito','dezenove','vinte')

teclado = int(input('Digite um número entre 0 e 20: '))
while teclado < 0 or teclado >20:
    teclado = int(input('Digite um número entre 0 e 20: '))
print(n[teclado])