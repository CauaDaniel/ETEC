n = ( int(input('Digite um número do teclado: ')),
      int(input('Digite outro número do teclado: ')),
      int(input('Digite novamente um número do teclado: ')),
      int(input('Por fim. Digite mais um ultimo número: ')))
print('Valor 9 aparece:',n.count(9),'vezes')
if 3 in n:
    print('3 está na',n.index(3)+1,'ª posição')
else:
    print('O valor 3 não foi digitado. Não está em nenhuma posição')
print('Os pares são: ')
for n1 in n:
    if n1 % 2 == 0:
        print(n1,end=' ')


